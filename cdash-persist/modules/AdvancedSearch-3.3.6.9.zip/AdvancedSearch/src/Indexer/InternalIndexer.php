<?php declare(strict_types=1);

namespace AdvancedSearch\Indexer;

class InternalIndexer extends NoopIndexer
{
}
