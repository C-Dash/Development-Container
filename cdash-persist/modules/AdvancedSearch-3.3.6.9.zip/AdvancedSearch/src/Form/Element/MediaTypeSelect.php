<?php declare(strict_types=1);
namespace AdvancedSearch\Form\Element;

use Laminas\Form\Element\Select;

class MediaTypeSelect extends Select
{
}
