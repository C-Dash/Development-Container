<?php declare(strict_types=1);

namespace AdvancedSearch\View\Helper;

class FacetSelect extends AbstractFacet
{
    protected $partial = 'search/facet-select';
}
