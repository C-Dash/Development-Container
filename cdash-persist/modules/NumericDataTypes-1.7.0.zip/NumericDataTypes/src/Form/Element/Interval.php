<?php
namespace NumericDataTypes\Form\Element;

class Interval extends DateTime
{
}
