<?php
namespace BulkImport\Form\Reader;

class OmekaSReaderConfigForm extends AbstractReaderConfigForm
{
}
