<?php
namespace BulkImport\Form\Processor;

class OmekaSProcessorConfigForm extends AbstractResourceProcessorConfigForm
{
}
